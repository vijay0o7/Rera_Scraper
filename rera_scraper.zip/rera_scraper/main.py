from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, ElementClickInterceptedException, StaleElementReferenceException
from bs4 import BeautifulSoup
import pandas as pd
import time
def safe_text(soup, selector_type, selector):
    try:
        if selector_type == "id":
            elem = soup.find(id=selector)
        elif selector_type == "class":
            elem = soup.find(class_=selector)
        else:
            elem = None
        return elem.text.strip() if elem else ""
    except Exception:
        return ""
def main():
    print("🚀 Starting scraper...")
    options = Options()
    options.add_argument("--start-maximized")
    options.add_argument("--disable-notifications")
    options.add_argument("--disable-popup-blocking")
    service = Service("chromedriver.exe")
    driver = webdriver.Chrome(service=service, options=options)
    wait = WebDriverWait(driver, 15) 
    url = "https://rera.odisha.gov.in/projects/project-list"
    driver.get(url)
    try:
        wait.until(EC.presence_of_all_elements_located((By.LINK_TEXT, "View Details")))
    except TimeoutException:
        print("⚠️ Project list did not load properly.")
        driver.quit()
        return
    data = []
    for i in range(6):
        try:
            wait.until(EC.presence_of_all_elements_located((By.LINK_TEXT, "View Details")))
            project_links = driver.find_elements(By.LINK_TEXT, "View Details")[:6]
            driver.execute_script("arguments[0].scrollIntoView(true);", project_links[i])
            time.sleep(0.5)  
            try:
                project_links[i].click()
            except ElementClickInterceptedException:
                driver.execute_script("arguments[0].click();", project_links[i])
            wait.until(EC.presence_of_element_located((By.ID, "lblReraRegistrationNumber")))
            soup = BeautifulSoup(driver.page_source, "html.parser")
            rera_no = safe_text(soup, "id", "lblReraRegistrationNumber")
            project_name = safe_text(soup, "id", "lblProjectName")
            promoter_name = safe_text(soup, "id", "lblPromoterName")
            try:
                promoter_tab = wait.until(EC.element_to_be_clickable((By.XPATH, "//a[contains(text(),'Promoter Details')]")))
                promoter_tab.click()
                wait.until(EC.presence_of_element_located((By.ID, "lblRegAddress")))
                soup = BeautifulSoup(driver.page_source, "html.parser")
                address = safe_text(soup, "id", "lblRegAddress")
                gst = safe_text(soup, "id", "lblGSTNumber")
            except Exception:
                address = ""
                gst = ""
            data.append({
                "Rera Regd. No": rera_no,
                "Project Name": project_name,
                "Promoter Name": promoter_name,
                "Promoter Address": address,
                "GST No.": gst
            })
            print(f"✅ Project {i+1} scraped.")
            driver.back()
            wait.until(EC.presence_of_all_elements_located((By.LINK_TEXT, "View Details")))
            time.sleep(1)  
        except TimeoutException:
            print(f"⚠️ Timeout loading project {i+1} details, retrying...")
            driver.get(url)
            wait.until(EC.presence_of_all_elements_located((By.LINK_TEXT, "View Details")))
            time.sleep(2)
        except StaleElementReferenceException:
            print(f"⚠️ StaleElementReferenceException on project {i+1}, retrying...")
            driver.get(url)
            wait.until(EC.presence_of_all_elements_located((By.LINK_TEXT, "View Details")))
            time.sleep(2)
        except Exception as e:
            print(f"❌ Error scraping project {i+1}: {e}")
            driver.get(url)
            wait.until(EC.presence_of_all_elements_located((By.LINK_TEXT, "View Details")))
            time.sleep(2)
    driver.quit()
    df = pd.DataFrame(data)
    df.to_csv("rera_projects.csv", index=False)
    print("📁 Data saved to rera_projects.csv")
if __name__ == "__main__":
    main()
